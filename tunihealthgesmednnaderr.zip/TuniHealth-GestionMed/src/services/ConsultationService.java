
package services;

import entities.Consultation;
import entities.Medecin;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import tools.MyConnection;

/**
 *
 * @author anasb
 */
public class ConsultationService {
     private Connection cnx;
    private PreparedStatement ste;

    public ConsultationService() {
        cnx = MyConnection.getInstance().getConnection();
    }

    public void ajouterConsultation(Consultation consultation){
        String req ="INSERT INTO consultations (idMed,cinPatient,type,duree,date,horaire)"+"values (?,?,?,?,?,?)";
        try {
            ste = cnx.prepareStatement(req);
            ste.setLong(1, consultation.getIdMed());
            ste.setString(2, consultation.getCinCitoyen());
            ste.setString(3,consultation.getType());
            ste.setInt(4,consultation.getDuree());
            ste.setDate(5,consultation.getDate());
            ste.setTime(6,consultation.getHoraire());
            int rowsInserted = ste.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Consultation ajoutée");
            }
        } catch (SQLException ex) {

        }

    }
    public List<Consultation> afficherConsultationParamMed(long idMed){
        List<Consultation> consultations = new ArrayList<>();

        try {
            String sql = "select * from Consultations where idMed=?";

            ste = cnx.prepareStatement(sql);
            ste.setLong(1,idMed);
            ResultSet rs = ste.executeQuery();
            while (rs.next()) {
                Consultation consultation = new Consultation();
                consultation.setIdMed(rs.getLong("idMed"));
                consultation.setCinCitoyen(rs.getString("cinPatient"));
                consultation.setType(rs.getString("type"));
                consultation.setDate(rs.getDate("date"));
                consultation.setDuree(rs.getInt("duree"));
                consultation.setHoraire(rs.getTime("horaire"));
                consultations.add(consultation);

            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return  consultations;

    }

    public void supprimerConsultation(long id){
        try {

            String sql = "DELETE FROM Medecins WHERE idConsultation=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setLong(1, id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A visit was deleted successfully!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public Consultation selectConsultation(long id){
        Consultation consultation = new Consultation();
        try {
            String sql = "SELECT * FROM Medecins WHERE id=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setLong(1,id);
            ResultSet rs = ste.executeQuery();
              
                consultation.setIdMed(rs.getLong("idMed"));
                consultation.setCinCitoyen(rs.getString("cinPatient"));
                consultation.setType(rs.getString("type"));
                consultation.setDate(rs.getDate("date"));
                consultation.setDuree(rs.getInt("duree"));
                consultation.setHoraire(rs.getTime("horaire"));
                

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());;
        }
        return consultation ;
    }

    public void modifierConsultation(long target,long idMed,String cinPatient, String type ,int duree, Date date, Time horaire){
        try  {

            String sql = "UPDATE Consultations SET idMed=?, cinPatient=?, type=?,duree=?,date=?,horaire=?, WHERE idMed=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
             ste.setLong(1, idMed);
            ste.setString(2, cinPatient);
            ste.setString(3,type);
            ste.setInt(4,duree);
            ste.setDate(5,date);
            ste.setTime(6, horaire);
            ste.setLong(7,target);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing Doctor was updated successfully!");
            }


        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
