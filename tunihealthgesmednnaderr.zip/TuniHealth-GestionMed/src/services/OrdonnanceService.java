/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Medecin;
import entities.Medicament;
import entities.Ordonnance;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tools.MyConnection;

/**
 *
 * @author anasb
 */
public class OrdonnanceService {

    private Connection cnx;
    private PreparedStatement ste;

    public OrdonnanceService() {
        cnx = MyConnection.getInstance().getConnection();
    }

    public void ajouterOrdonnance(Ordonnance ordonnance) {
        String req = "INSERT INTO Ordonnances (idMed,cinPatient,medicaments,date)" + "values (?,?,?,?)";
        try {
            ste = cnx.prepareStatement(req);
            ste.setLong(1, ordonnance.getIdMed());
            ste.setString(2, ordonnance.getCinPatient());
            ste.setString(3, ordonnance.getMedicaments());
            ste.setString(4, ordonnance.getDate().toString());
            int rowsInserted = ste.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Medecin ajouté");
            }
        } catch (SQLException ex) {

        }

    }

    public List<Ordonnance> afficherOrdonnancesParamMed(long target) {
        List<Ordonnance> ordonnances = new ArrayList<>();

        try {
            String sql = "select * from Ordonnances where medId=?";

            ste = cnx.prepareStatement(sql);
            ste.setLong(1, target);
            ResultSet rs = ste.executeQuery();
            while (rs.next()) {
                Ordonnance ordonnance = new Ordonnance();
                ordonnance.setIdMed(rs.getLong("idMed"));
                ordonnance.setCinPatient(rs.getString("cinPatient"));
                ordonnance.setMedicaments(rs.getString("medicaments"));
                ordonnance.setDate(rs.getDate("date"));
                ordonnances.add(ordonnance);

            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return ordonnances;

    }
    
        public List<Ordonnance> afficherOrdonnancesParamCitoyen(String target) {
        List<Ordonnance> ordonnances = new ArrayList<>();

        try {
            String sql = "select * from Ordonnances where cinPatient = ?";
            ste.setString(1, target);
            ste = cnx.prepareStatement(sql);
            ResultSet rs = ste.executeQuery();
            while (rs.next()) {
                Ordonnance ordonnance = new Ordonnance();
                ordonnance.setIdMed(rs.getLong("idMed"));
                ordonnance.setCinPatient(rs.getString("cinPatient"));
                ordonnance.setMedicaments(rs.getString("medicaments"));
                ordonnance.setDate(rs.getDate("date"));
                ordonnances.add(ordonnance);

            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return ordonnances;

    }

    public void supprimerOrdonnance(long id) {
        try {

            String sql = "DELETE FROM Ordonnances WHERE date=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setLong(1, id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A doctor was deleted successfully!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public Ordonnance selectOrdonnance(long id) {
        Ordonnance ordonnance = new Ordonnance();
        try {
            String sql = "SELECT * FROM Medecins WHERE ordonnanceId=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setLong(1, id);
            ResultSet rs = ste.executeQuery();

            ordonnance.setIdMed(rs.getLong("idMed"));
            ordonnance.setCinPatient(rs.getString("cinPatient"));
            ordonnance.setMedicaments(rs.getString("medicaments"));
            ordonnance.setDate(rs.getDate("date"));

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());;
        }
        return ordonnance;
    }

    public void modifierOrdonnance(long target, long medId, String cinPatient, String medicaments, Date date) {
        try {

            String sql = "UPDATE Medecins SET nom=?, prenom=?, specialite=?,adresse=?,numTel=?,evaluation=?,horaires=?,joursTravail=?,prixVisite=?,hospitalier=?,conventionne=?, WHERE idMed=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            ste.setLong(1, medId);
            ste.setString(2, cinPatient);
            ste.setString(3, medicaments);
            ste.setDate(4, date);
            ste.setLong(5, target);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing Doctor was updated successfully!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
