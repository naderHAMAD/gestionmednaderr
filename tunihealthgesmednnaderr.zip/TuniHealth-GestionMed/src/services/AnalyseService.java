   /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import tools.MyConnection;
import java.sql.*;
import entities.Analyse;
import java.util.*;
import javax.swing.*;  


/**
 *
 * @author lenovo
 */
public class AnalyseService {
    public Connection cnx;
     public PreparedStatement ste;
    public AnalyseService() {
    cnx = MyConnection.getInstance().getConnection();
}
  public void ajouterAnalyse(Analyse a)  {
      try {
      String sql = "INSERT INTO anlyses (patientnom, patientprenom, gr, gb, Lymphocyte, Monocyte, vgm, Reticulocyte , Hemoglobine ) VALUES (?,?,?,?,?,?,?,?,?)";
      ste=cnx.prepareStatement(sql);
      ste.setString(1, a.getNom());
      ste.setString(2, a.getPrenom());
      ste.setFloat(3, a.getId());      
      ste.setFloat(4, a.getGr());
      ste.setFloat(5, a.getGb());
      ste.setFloat(6, a.getLymphocyte());
      ste.setFloat(7, a.getMonocyte());
      ste.setFloat(8, a.getVgm());   
      ste.setFloat(9, a.getReticulocyte());   
      ste.setFloat(10, a.getHemoglobine());   
      
      
      
      ste.executeUpdate();
      System.out.println("analyse ajouté");

  }catch (SQLException ex) { System.out.println(ex.getMessage());
 
  }
  }


public List<Analyse> afficherAnalyse(){
    List<Analyse> analyses = new ArrayList<>();
   
        try {
             String sql = "select * from anlyses";
     
             ste = cnx.prepareStatement(sql);
             ResultSet rs = ste.executeQuery();
             while (rs.next()) {   
                 Analyse a = new Analyse();
                 
                 a.setNom(rs.getString("patientnom"));
                 a.setPrenom(rs.getString("patientprenom"));
                 a.setId(rs.getFloat("id"));                 
                 a.setGr(rs.getFloat("gr"));
                 a.setGb(rs.getFloat("gb"));
                 a.setLymphocyte(rs.getFloat("Lymphocyte"));
                 a.setMonocyte(rs.getFloat("Monocyte"));
                 a.setVgm(rs.getFloat("vgm"));
                 a.setReticulocyte(rs.getFloat("Reticulocyte"));
                 a.setHemoglobine(rs.getFloat("Hemoglobine"));

                 analyses.add(a);
                 System.out.println(rs.getString("patientnom"));
                 System.out.println("prenom = " +rs.getString("patientprenom"));
                 System.out.println("id =" +rs.getFloat("id"));
                 
                 System.out.println("globule rouge =" +rs.getFloat("gr"));
                 System.out.println("globule blanc =" + rs.getFloat("gb"));
                 System.out.println("lymphocyte="+rs.getFloat("Lymphocyte"));
                 System.out.println("monocyte=" + rs.getFloat("Monocyte"));
                
                 System.out.println("vgm = " + rs.getFloat("vgm"));
                 System.out.println("Reticulocyte = " + rs.getFloat("Reticulocyte"));
                 System.out.println("Hemoglobine = " + rs.getFloat("Hemoglobine"));
             
             
             }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    
    return analyses;
   
}


public void updateAnalyse(Analyse a)  {        
        try {
           String sql ="UPDATE anlyses SET patientnom=?, patientprenom=?,gr=?,gb=?,Lymphocyte=?,Monocyte=?,vgm=? , Reticulocyte=? ,Hemoglobine=? WHERE id=?";
            ste = cnx.prepareStatement(sql);
            
            
            ste.setString(1, a.getNom());
            ste.setString(2, a.getPrenom());
            ste.setFloat(3, a.getGr());            
            ste.setFloat(4, a.getGb());
            ste.setFloat(5, a.getLymphocyte());
            ste.setFloat(6, a.getMonocyte());
            ste.setFloat(6, a.getVgm());
            
            ste.setFloat(7, a.getReticulocyte());
            ste.setFloat(8, a.getHemoglobine());
            
            
            
            ste.executeUpdate();
            System.out.println("modification terminé");
            
        } catch (SQLException ex) {
            JOptionPane.showInternalMessageDialog(null, ex);
                      
        }
        
    }

public void delete( float id){
        try {
           String sql ="DELETE FROM anlyses WHERE id=?";
            ste = cnx.prepareStatement(sql);
             
            ste.setFloat(1, id);
            ste.execute();
            System.out.println("analyse supprimé");
            
        } catch (SQLException ex) {
            JOptionPane.showInternalMessageDialog(null, ex);
                      
        }
        
    }
}