
package services;

import entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import tools.MyConnection;

/**
 *
 * @author anasb
 */
public class UserService {
    private Connection cnx;
    private PreparedStatement ste;

    public UserService() {
        cnx = MyConnection.getInstance().getConnection();
    }
    
     public void ajouterUser(User user){
        String req ="INSERT INTO Users (email,password,role)"+"values (?,?,?)";
        try {
            ste = cnx.prepareStatement(req);
            ste.setString(1, user.getEmail());
            ste.setString(2, user.getPwd());
            ste.setString(3,user.getRole());
            int rowsInserted = ste.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("user added successfully");
            }
        } catch (SQLException ex) {

        }

    }
    
    public boolean rechercheUser(String email) throws SQLException{
        boolean existe = false;
        try{
            String sql = "select * from Users where email=?";
        PreparedStatement statement = cnx.prepareStatement(sql);
        statement.setString(1,email);
        ResultSet rs = statement.executeQuery();
        if (!rs.next()){
            existe = false;
        } else
            existe = true;
        } catch(SQLException se){
            System.out.println(se.getMessage());
        }
        return existe;
    }
    
    public User selectUser(String email){
        User user = new User();
        try {
            String sql = "SELECT * FROM Users WHERE id=? ";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setString(1,email);
            ResultSet rs = ste.executeQuery();
            user.setId(rs.getLong("id"));
            user.setEmail(rs.getString("email"));
            user.setPwd(rs.getString("password"));
            user.setRole(rs.getString("role"));
                

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());;
        }
        return user ;
    }
    
   public boolean login(String email, String pwd){
       
       return true;
        
   }
   
       public void modifierUser(String email,String pwd,String target){
        try  {

            String sql = "UPDATE Users SET email=?, password=? WHERE email=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, pwd);
            statement.setString(3, target);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing user was updated successfully!");
            }


        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
       
       public void supprimerMedecin(String email){
        try {

            String sql = "DELETE FROM Medecins WHERE idMed=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
            statement.setString(1, email);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A User was deleted successfully!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
}
