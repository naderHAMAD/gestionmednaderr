package services;

import entities.Medecin;
import tools.MyConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MedecinService {
    private Connection cnx;
    private PreparedStatement ste;

    public MedecinService() {
        cnx = MyConnection.getInstance().getConnection();
    }

    public void ajouterMedecin(Medecin medecin){
        String req ="INSERT INTO medecin123 (nom,prenom,specialite,numTel,adresse,region,evaluation,nbEvaluations,horaires,joursTravail,prixVisite,hospitalier,conventionne)"+"values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            ste = cnx.prepareStatement(req);
            ste.setString(1, medecin.getNom());
            ste.setString(2, medecin.getPrenom());
            ste.setString(3,medecin.getSpecialite());
            ste.setString(5,medecin.getAdresseCabinet());
            ste.setString(6, medecin.getRegion());
            ste.setString(4,medecin.getNumTelPro());
            ste.setFloat(7, medecin.getRating());
            ste.setInt(8,medecin.getNombreRatings());
            ste.setString(9,medecin.getHorairesDispo());
            ste.setString(10,medecin.getJoursTravail());
            ste.setInt(11,medecin.getPrixVisite());
            ste.setBoolean(12, medecin.isHospitalier());
            ste.setBoolean(13,medecin.isConventionne());
            int rowsInserted = ste.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Medecin ajouté");
            }
        } catch (SQLException ex) {
            System.out.println("Erreur d'ajout");
        }

    }
    public List<Medecin> afficherMedecins(){
        List<Medecin> medecins = new ArrayList<>();

        try {
            String sql = "select * from medecin123";

            ste = cnx.prepareStatement(sql);
            ResultSet rs = ste.executeQuery();
            while (rs.next()) {
                Medecin medecin = new Medecin();
                medecin.setNom(rs.getString("nom"));
                medecin.setPrenom(rs.getString("prenom"));
                medecin.setSpecialite(rs.getString("specialite"));
                medecin.setAdresseCabinet(rs.getString("adresse"));
                medecin.setNumTelPro(rs.getString("region"));
                medecin.setNumTelPro(rs.getString("numTel"));
                medecin.setRating(rs.getFloat("evaluation"));
                medecin.setNombreRatings(rs.getInt("nbEvaluations"));
                medecin.setHorairesDispo(rs.getString("horaires"));
                medecin.setJoursTravail(rs.getString("joursTravail"));
                medecin.setPrixVisite(rs.getInt("prixVisite"));
                medecin.setHospitalier(rs.getBoolean("hospitalier"));
                medecin.setConventionne(rs.getBoolean("conventionne"));
                

                medecins.add(medecin);

            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return  medecins;

    }
    public ObservableList<Medecin> getAnalyse(){
    ObservableList<Medecin> medecins = FXCollections.observableArrayList();
    
   
        try {
             String sql = "select * from medecin123";
     
             ste = cnx.prepareStatement(sql);
             ResultSet rs = ste.executeQuery();
             while (rs.next()) {   
                Medecin medecin = new Medecin();
                medecin.setNom(rs.getString("nom"));
                medecin.setPrenom(rs.getString("prenom"));
                medecin.setSpecialite(rs.getString("specialite"));
                medecin.setAdresseCabinet(rs.getString("adresse"));
                medecin.setNumTelPro(rs.getString("region"));
                medecin.setNumTelPro(rs.getString("numTel"));
                medecin.setRating(rs.getFloat("evaluation"));
                medecin.setNombreRatings(rs.getInt("nbEvaluations"));
                medecin.setHorairesDispo(rs.getString("horaires"));
                medecin.setJoursTravail(rs.getString("joursTravail"));
                medecin.setPrixVisite(rs.getInt("prixVisite"));
                medecin.setHospitalier(rs.getBoolean("hospitalier"));
                medecin.setConventionne(rs.getBoolean("conventionne"));
                

             
             }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    
    return medecins;
   
}

    public void supprimerMedecin(int id){
        try {

            String sql = "DELETE FROM medecin123 WHERE idMed=?";

            ste = cnx.prepareStatement(sql);
            ste.setInt(1,id);
            int rowsDeleted = ste.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A doctor was deleted successfully!");
            }       } catch (SQLException ex) {
        }
}        

    public Medecin selectMedecin(long id){
        Medecin medecin = new Medecin();
        try {
            String sql = "SELECT * FROM medecin123 WHERE idMed=?";

            ste = cnx.prepareStatement(sql);
            ste.setLong(1,id);
            ResultSet rs = ste.executeQuery();
              
                medecin.setNom(rs.getString("nom"));
                medecin.setPrenom(rs.getString("prenom"));
                medecin.setSpecialite(rs.getString("specialite"));
                medecin.setAdresseCabinet(rs.getString("adresse"));
                medecin.setNumTelPro(rs.getString("region"));
                medecin.setNumTelPro(rs.getString("numTel"));
                medecin.setRating(rs.getFloat("evaluation"));
                medecin.setNombreRatings(rs.getInt("nbEvaluations"));
                medecin.setHorairesDispo(rs.getString("horaires"));
                medecin.setJoursTravail(rs.getString("joursTravail"));
                medecin.setPrixVisite(rs.getInt("prixVisite"));
                medecin.setHospitalier(rs.getBoolean("hospitalier"));
                medecin.setConventionne(rs.getBoolean("conventionne"));
                

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());;
        }
        return medecin ;
    }
    
        public Medecin selectMedecinNomPrenom(String nom,String prenom){
        Medecin medecin = new Medecin();
        try {
            String sql = "SELECT * FROM medecin123 WHERE nom=? AND prenom=?;";

                ste = cnx.prepareStatement(sql);
                ste.setString(1,nom);
                ste.setString(2,prenom);
                ResultSet rs = ste.executeQuery();
              
                medecin.setNom(rs.getString("nom"));
                medecin.setPrenom(rs.getString("prenom"));
                medecin.setSpecialite(rs.getString("specialite"));
                medecin.setAdresseCabinet(rs.getString("adresse"));
                medecin.setRegion(rs.getString("region"));
                medecin.setNumTelPro(rs.getString("numTel"));
                medecin.setRating(rs.getFloat("evaluation"));
                medecin.setNombreRatings(rs.getInt("nbEvaluations"));
                medecin.setHorairesDispo(rs.getString("horaires"));
                medecin.setJoursTravail(rs.getString("joursTravail"));
                medecin.setPrixVisite(rs.getInt("prixVisite"));
                medecin.setHospitalier(rs.getBoolean("hospitalier"));
                medecin.setConventionne(rs.getBoolean("conventionne"));
                

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());;
        }
        return medecin ;
    }

    public void modifierMedecin(Medecin m){
        try  {

            String sql = "UPDATE Medecin123 SET nom=?, prenom=?, specialite=?,adresse=?,region=?,numTel=?,horaires=?,joursTravail=?,prixVisite=?,hospitalier=?,conventionne=?, WHERE idMed=?";

            PreparedStatement statement = cnx.prepareStatement(sql);
             ste.setString(1, m.getNom());
            ste.setString(2, m.getPrenom());
            ste.setString(3,m.getSpecialite());
            ste.setString(4,m.getAdresseCabinet());
            ste.setString(5, m.getRegion());
            ste.setString(6,m.getNumTelPro());
            ste.setString(7,m.getRegion());
            ste.setString(8,m.getJoursTravail());
            ste.setInt(9,m.getPrixVisite());
            ste.setBoolean(10, m.isHospitalier());
            ste.setBoolean(11,m.isConventionne());
          
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing Doctor was updated successfully!");
            }


        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
