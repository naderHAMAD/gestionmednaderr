/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Medecin;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;
import services.MedecinService;
import static sun.io.Win32ErrorMode.initialize;
import static sun.management.jmxremote.ConnectorBootstrap.initialize;
import static sun.management.jmxremote.ConnectorBootstrap.initialize;
import static sun.management.snmp.AdaptorBootstrap.initialize;
import static sun.management.snmp.AdaptorBootstrap.initialize;
import static sun.misc.OSEnvironment.initialize;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;







    
    public class Dashboard implements Initializable {
    @FXML
    private ImageView imageView;
    @FXML
    private Button modifierProfilBtn;
    @FXML
    private Button creerOdonnanceBtn;
    @FXML
    private Label nomFld;
    @FXML
    private Label prenomFld;
    @FXML
    private Label specialiteFld;
    @FXML
    private Label numTelFld;
    @FXML
    private Button changePhotoBtn;
    @FXML
    private ListView<?> listeConsultations;
    @FXML
    private Button modifierProfilSanitaireBtn;
    @FXML
    private Button supprimerProfilBtn;
    @FXML
    private Button retourProfilBtn;
    @FXML
    private TableView<Medecin> tv;
    @FXML
    private TableColumn<Medecin, Integer > cl;
    @FXML
    private TableColumn<Medecin, String> c2;
    @FXML
    private TableColumn<Medecin, String> c3;
    @FXML
    private TableColumn<Medecin, String> c4;
    @FXML
    private TableColumn<Medecin, String> c5;
    @FXML
    private TableColumn<Medecin, String> c6;
    @FXML
    private Button afficher;
    @FXML
    private Button retour;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @FXML
    private void modifierProfil(ActionEvent event) {
    }

    @FXML
    private void creerOrdonnance(ActionEvent event) {
    }

    @FXML
    private void changePhoto(ActionEvent event) {
    }

    @FXML
    private void modifierProfilSanitaire(ActionEvent event) {
    }

    @FXML
    private void supprimerProfil(ActionEvent event) {
    }

    @FXML
    private void retourProfil(ActionEvent event) {
    }

    @FXML
    private void afficher(ActionEvent event) {
    }
    
    public class DashboardController implements Initializable {

    @FXML
    private TextField LMedecin;
    @FXML
    private Button retour;

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
     public void setLMedecin(String LMedecin){
        this.LMedecin.setText(LMedecin);
    }    

    @FXML
    private void modifierProfil(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifierMed.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
                MedecinService ms = new MedecinService();
                Medecin med = ms.selectMedecin(3);
                System.out.println(med);
                ModifierMedController mmd = new ModifierMedController();
                mmd.setTarget(med);
             /*   mmd.getNomFld().setText(med.getNom());
                mmd.getPrenomFld().setText(med.getNom());
                mmd.getSpecialiteBox().setText(med.getSpecialite());
                mmd.getAdresseFld().setText(med.getAdresseCabinet());
                mmd.getRegionBox().setText(med.getRegion());
                mmd.getNumTelFld().setText(med.getNumTelPro());
                mmd.getHoraireDispoFld().setText(med.getHorairesDispo());
                mmd.getJoursTravailFld().setText(med.getJoursTravail());
                mmd.getPrixFld().setText(String.valueOf(med.getPrixVisite()));*/
                
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    private void creerOrdonnance(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AjouterOrdonnance.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    private void changePhoto(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
             
            //Set extension filter
            FileChooser.ExtensionFilter extFilterJPG = 
                    new FileChooser.ExtensionFilter("JPG files (*.JPG)", "*.JPG");
            FileChooser.ExtensionFilter extFilterjpg = 
                    new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
            FileChooser.ExtensionFilter extFilterPNG = 
                    new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
            FileChooser.ExtensionFilter extFilterpng = 
                    new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
            fileChooser.getExtensionFilters()
                    .addAll(extFilterJPG, extFilterjpg, extFilterPNG, extFilterpng);

            //Show open file dialog
            File file = fileChooser.showOpenDialog(null);
            
            try {
                BufferedImage bufferedImage = ImageIO.read(file);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                imageView.setImage(image);
            } catch (IOException ex) {
                Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    private void modifierProfilSanitaire(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ProfilSanitaire.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
                ModifierMedController medC = new ModifierMedController();
                
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    private void supprimer(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SupprimerMedecin.fxml"));
                    Parent r = loader.load();

            creerOdonnanceBtn.getScene().setRoot(r);

    }

    @FXML
    private void retourProfil(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

 
        public void show(){
    ObservableList<Medecin> analyses;
               MedecinService an = new MedecinService();

    analyses = an.getAnalyse();
        

        c2.setCellValueFactory(new PropertyValueFactory<>("nom"));
        c3.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        c4.setCellValueFactory(new PropertyValueFactory<>("specialite"));
        c5.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        c6.setCellValueFactory(new PropertyValueFactory<>("region"));

        tv.setItems(analyses);
    
    
    
       }
 
    @FXML
    private void afficher(ActionEvent event) {
        show();
    }

    
}
}
    