/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Medecin;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import services.MedecinService;

/**
 * FXML Controller class
 *
 * @author anasb
 */
public class ModifierMedController implements Initializable {

    private TextField nomFld;
    private TextField prenomFld;
    private TextField adresseFld;
    private TextField specialiteBox;
    private TextField regionBox;
    private TextField numTelFld;
    private TextField joursTravailFld;
    private TextField prixFld;
    @FXML
    private RadioButton ouiHospitalier;
    @FXML
    private ToggleGroup hospitalier;
    @FXML
    private RadioButton nonHospitalier;
    @FXML
    private RadioButton ouiConvention;
    @FXML
    private ToggleGroup convention;
    @FXML
    private RadioButton nonConvention;
    @FXML
    private Button modifierMedBtn;
    private TextField horaireDispoFld;
    @FXML
    private Button retourModifMedBtn;
    
    private Medecin target ;
    @FXML
    private TextField a;
    @FXML
    private TextField b;
    @FXML
    private TextField d;
    @FXML
    private TextField f;
    @FXML
    private TextField h;
    @FXML
    private TextField i;
    @FXML
    private TextField g;
    @FXML
    private TextField c;
    @FXML
    private TextField e;
    @FXML
    private TextField txtid;

    public Medecin getTarget() {
        return target;
    }

    public void setTarget(Medecin target) {
        this.target = target;
    }
    
    public TextField getNomFld() {
        return nomFld;
    }

    public void setNomFld(TextField nomFld) {
        this.nomFld = nomFld;
    }

    public TextField getPrenomFld() {
        return prenomFld;
    }

    public void setPrenomFld(TextField prenomFld) {
        this.prenomFld = prenomFld;
    }

    public TextField getAdresseFld() {
        return adresseFld;
    }

    public void setAdresseFld(TextField adresseFld) {
        this.adresseFld = adresseFld;
    }

    public TextField getSpecialiteBox() {
        return specialiteBox;
    }

    public void setSpecialiteBox(TextField specialiteBox) {
        this.specialiteBox = specialiteBox;
    }

    public TextField getRegionBox() {
        return regionBox;
    }

    public void setRegionBox(TextField regionBox) {
        this.regionBox = regionBox;
    }

  

    public TextField getNumTelFld() {
        return numTelFld;
    }

    public void setNumTelFld(TextField numTelFld) {
        this.numTelFld = numTelFld;
    }

    public TextField getJoursTravailFld() {
        return joursTravailFld;
    }

    public void setJoursTravailFld(TextField joursTravailFld) {
        this.joursTravailFld = joursTravailFld;
    }

    public TextField getPrixFld() {
        return prixFld;
    }

    public void setPrixFld(TextField prixFld) {
        this.prixFld = prixFld;
    }

    public RadioButton getOuiHospitalier() {
        return ouiHospitalier;
    }

    public void setOuiHospitalier(RadioButton ouiHospitalier) {
        this.ouiHospitalier = ouiHospitalier;
    }

    public ToggleGroup getHospitalier() {
        return hospitalier;
    }

    public void setHospitalier(ToggleGroup hospitalier) {
        this.hospitalier = hospitalier;
    }

    public RadioButton getNonHospitalier() {
        return nonHospitalier;
    }

    public void setNonHospitalier(RadioButton nonHospitalier) {
        this.nonHospitalier = nonHospitalier;
    }

    public RadioButton getOuiConvention() {
        return ouiConvention;
    }

    public void setOuiConvention(RadioButton ouiConvention) {
        this.ouiConvention = ouiConvention;
    }

    public ToggleGroup getConvention() {
        return convention;
    }

    public void setConvention(ToggleGroup convention) {
        this.convention = convention;
    }

    public RadioButton getNonConvention() {
        return nonConvention;
    }

    public void setNonConvention(RadioButton nonConvention) {
        this.nonConvention = nonConvention;
    }

    public Button getModifierMedBtn() {
        return modifierMedBtn;
    }

    public void setModifierMedBtn(Button modifierMedBtn) {
        this.modifierMedBtn = modifierMedBtn;
    }

    public TextField getHoraireDispoFld() {
        return horaireDispoFld;
    }

    public void setHoraireDispoFld(TextField horaireDispoFld) {
        this.horaireDispoFld = horaireDispoFld;
    }

    public Button getRetourModifMedBtn() {
        return retourModifMedBtn;
    }

    public void setRetourModifMedBtn(Button retourModifMedBtn) {
        this.retourModifMedBtn = retourModifMedBtn;
    }

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void modifierMedecin(ActionEvent event) {
            int rid =Integer.parseInt(txtid.getText());
            String rnom2 = a.getText() ;
            String rprenom2 = b.getText() ;
            String rspecialite2 = c.getText() ;
            String rcontact2 =d.getText() ;
            String rcabinet2 = e.getText() ;
            String rhopital2 = f.getText() ;
            String rcontact3 =g.getText() ;
            String rcabinet4 = h.getText() ;
            String rhopital5 = i.getText() ;
             boolean hos = false;
             boolean conv = false;        
             if (ouiHospitalier.isSelected()){
                 hos = true;
                }
                else{
                 hos = false;
                }
             if (ouiConvention.isSelected()){
                 conv = true;
                }
                else{
                 conv = false;
                }
            
            
            Medecin m = new Medecin( rid ,rnom2, rprenom2, rspecialite2, rcontact2, rcabinet2, rhopital2, rcontact3 ,rcabinet4 ,rhopital5,hos,conv);
            MedecinService ms = new MedecinService();
            ms.modifierMedecin(m);
        
        
        
    }

    @FXML
    private void retourModifierBtn(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
}
