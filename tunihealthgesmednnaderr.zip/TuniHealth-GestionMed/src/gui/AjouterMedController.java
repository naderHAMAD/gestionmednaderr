/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Medecin;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import services.MedecinService;

/**
 * FXML Controller class
 *
 * @author anasb
 */
public class AjouterMedController implements Initializable {

    @FXML
    private TextField nomFld;
    @FXML
    private TextField prenomFld;
    @FXML
    private TextField adresseFld;
    @FXML
    private TextField specialiteBox;
    @FXML
    private TextField regionBox;
    @FXML
    private TextField numTelFld;
    @FXML
    private TextField joursTravailFld;
    @FXML
    private TextField prixFld;
    @FXML
    private ToggleGroup hospitalier;
    @FXML
    private ToggleGroup convention;
    @FXML
    private RadioButton ouiHospitalier;
    @FXML
    private RadioButton nonHospitalier;
    @FXML
    private RadioButton ouiConvention;
    @FXML
    private RadioButton nonConvention;
    @FXML
    private TextField horaireDispoFld;
    @FXML
    private Button ajouterMedBtn;
    @FXML
    private Button retourAjoutMedBtn;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    private void retourModifBtn(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    private void ajouterMed(ActionEvent event) {
        MedecinService ms = new MedecinService();
        Medecin medecin = new Medecin();
                medecin.setNom(nomFld.getText());
                medecin.setPrenom(prenomFld.getText());
                medecin.setSpecialite(specialiteBox.getText());
                medecin.setAdresseCabinet(adresseFld.getText());
                medecin.setNumTelPro(numTelFld.getText());
                medecin.setRegion(regionBox.getText());
                medecin.setHorairesDispo(horaireDispoFld.getText());
                medecin.setJoursTravail(joursTravailFld.getText());
                medecin.setRating(0);
                medecin.setNombreRatings(0);
                medecin.setPrixVisite(Integer.parseInt(prixFld.getText()));
                if (ouiHospitalier.isSelected()){
                    medecin.setHospitalier(true);
                }
                else{
                    medecin.setHospitalier(false);
                }
                if (ouiConvention.isSelected()){
                    medecin.setConventionne(true);
                }
                else{
                    medecin.setConventionne(false);
                }
        ms.ajouterMedecin(medecin);
        Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Info");

		// alert.setHeaderText("Results:");
		alert.setContentText("Doctor added successfully!");

		alert.showAndWait();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
               
    }

    @FXML
    private void retourAjoutBtn(ActionEvent event) {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            try {
                Parent root = loader.load();
                nomFld.getScene().setRoot(root);
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    
}
