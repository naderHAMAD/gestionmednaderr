package entities;

public class User {
    private long id;
    private String pwd;
    private String email;
    private String role;

    public User() {
    }

    public User(String pwd, String role) {
        super();
        this.pwd = pwd;
        this.role = role;
    }

    public User(long id, String pwd, String email, String role) {
        this.id = id;
        this.pwd = pwd;
        this.email = email;
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", pwd='" + pwd + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
