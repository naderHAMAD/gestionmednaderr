
package entities;

import java.util.List;

/**
 *
 * @author anasb
 */
public class Laboratoire extends User {
    private long idLabo;
    private String nom;
    private String adresse;
    private String numTel;
    private List<Analyse> analyses;

    public Laboratoire(long idLabo, String nom, String adresse, String numTel, List<Analyse> analyses) {
        this.idLabo = idLabo;
        this.nom = nom;
        this.adresse = adresse;
        this.numTel = numTel;
        this.analyses = analyses;
    }

    public long getIdLabo() {
        return idLabo;
    }

    public void setIdLabo(long idLabo) {
        this.idLabo = idLabo;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public List<Analyse> getAnalyses() {
        return analyses;
    }

    public void setAnalyses(List<Analyse> analyses) {
        this.analyses = analyses;
    }

    @Override
    public String toString() {
        return "Laboratoire{" + "idLabo=" + idLabo + ", nom=" + nom + ", adresse=" + adresse + ", numTel=" + numTel + ", analyses=" + analyses + '}';
    }
    
    
}
