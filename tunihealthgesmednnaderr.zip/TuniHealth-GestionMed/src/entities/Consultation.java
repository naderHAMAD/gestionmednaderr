
package entities;

import java.sql.Date;
import java.sql.Time;


public class Consultation {
  private long consultationId;
  private long idMed;
  private String cinCitoyen;
  private String type;
  private int duree;
  private Date date;
  private Time horaire;

    public Consultation(long idMed, String cinCitoyen, String type, int duree, Date date, Time horaire) {
        this.idMed = idMed;
        this.cinCitoyen = cinCitoyen;
        this.type = type;
        this.duree = duree;
        this.date = date;
        this.horaire = horaire;
    }

    public Consultation() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public long getIdMed() {
        return idMed;
    }

    public void setIdMed(long idMed) {
        this.idMed = idMed;
    }

    public String getCinCitoyen() {
        return cinCitoyen;
    }

    public void setCinCitoyen(String cinCitoyen) {
        this.cinCitoyen = cinCitoyen;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getHoraire() {
        return horaire;
    }

    public void setHoraire(Time horaire) {
        this.horaire = horaire;
    }

    public long getConsultationId() {
        return consultationId;
    }

    public void setConsultationId(long consultationId) {
        this.consultationId = consultationId;
    }

    @Override
    public String toString() {
        return "Consultation{" + "idMed=" + idMed + ", cinCitoyen=" + cinCitoyen + ", type=" + type + ", duree=" + duree + ", date=" + date + ", horaire=" + horaire + '}';
    }

 
  
  
  
}
