package entities;

public class Medicament {
    private int idMedicament;
    private float prix;
    private String nomMedicament;
    private String categorie;
    private boolean avecOrdonnance;
    private int stock;

    public Medicament() {
    }

    public Medicament(int idMedicament,float prix, String nomMedicament, String categorie, boolean avecOrdonnance, int stock) {
        this.idMedicament = idMedicament;
        this.prix = prix;
        this.nomMedicament = nomMedicament;
        this.categorie = categorie;
        this.avecOrdonnance = avecOrdonnance;
        this.stock = stock;
    }

    public int getIdMedicament() {
        return idMedicament;
    }

    public void setIdMedicament(int idMedicament) {
        this.idMedicament = idMedicament;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public String getNomMedicament() {
        return nomMedicament;
    }

    public void setNomMedicament(String nomMedicament) {
        this.nomMedicament = nomMedicament;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public boolean isAvecOrdonnance() {
        return avecOrdonnance;
    }

    public void setAvecOrdonnance(boolean avecOrdonnance) {
        this.avecOrdonnance = avecOrdonnance;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Medicament{" +
                "prix=" + prix +
                ", nomMedicament='" + nomMedicament + '\'' +
                ", categorie='" + categorie + '\'' +
                ", avecOrdonnance=" + avecOrdonnance +
                '}';
    }
}
