package entities;

import java.util.List;

public class Pharmacie extends User {
    private long idPharmacie;
    private String nomPharmacie;
    private String type;
    private String adresse;
    private String numTel;
    private List<Stock> stock;

    public Pharmacie() {
    }

    public Pharmacie(String nomPharmacie, String type, String adresse, String numTel, List<Stock> stock) {
        this.nomPharmacie = nomPharmacie;
        this.type = type;
        this.adresse = adresse;
        this.numTel = numTel;
        this.stock = stock;
    }

    public long getIdPharmacie() {
        return idPharmacie;
    }

    public void setIdPharmacie(long idPharmacie) {
        this.idPharmacie = idPharmacie;
    }
    
    
    
    public String getNomPharmacie() {
        return nomPharmacie;
    }

    public void setNomPharmacie(String nomPharmacie) {
        this.nomPharmacie = nomPharmacie;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Stock> getStock() {
        return stock;
    }

    public void setStock(List<Stock> stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Pharmacie{" + "nomPharmacie=" + nomPharmacie + ", type=" + type + ", adresse=" + adresse + ", numTel=" + numTel + ", stock=" + stock + '}';
    }


}
