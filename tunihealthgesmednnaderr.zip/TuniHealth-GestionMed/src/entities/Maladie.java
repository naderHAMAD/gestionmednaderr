
package entities;

import java.util.Date;

/**
 *
 * @author anasb
 */
class Maladie {
    private long idCitoyen;
    private String nomMaladie;
    private Date dateAtteinte;
    private Date dateGuerison;
    private String symptomes;
    private String traitement;

    public Maladie(long idCitoyen, String nomMaladie, Date dateAtteinte, Date dateGuerison, String symptomes, String traitement) {
        this.idCitoyen = idCitoyen;
        this.nomMaladie = nomMaladie;
        this.dateAtteinte = dateAtteinte;
        this.dateGuerison = dateGuerison;
        this.symptomes = symptomes;
        this.traitement = traitement;
    }

    public long getIdCitoyen() {
        return idCitoyen;
    }

    public void setIdCitoyen(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public String getNomMaladie() {
        return nomMaladie;
    }

    public void setNomMaladie(String nomMaladie) {
        this.nomMaladie = nomMaladie;
    }

    public Date getDateAtteinte() {
        return dateAtteinte;
    }

    public void setDateAtteinte(Date dateAtteinte) {
        this.dateAtteinte = dateAtteinte;
    }

    public Date getDateGuerison() {
        return dateGuerison;
    }

    public void setDateGuerison(Date dateGuerison) {
        this.dateGuerison = dateGuerison;
    }

    public String getSymptomes() {
        return symptomes;
    }

    public void setSymptomes(String symptomes) {
        this.symptomes = symptomes;
    }

    public String getTraitement() {
        return traitement;
    }

    public void setTraitement(String traitement) {
        this.traitement = traitement;
    }

    @Override
    public String toString() {
        return "Maladie{" + "idCitoyen=" + idCitoyen + ", nomMaladie=" + nomMaladie + ", dateAtteinte=" + dateAtteinte + ", dateGuerison=" + dateGuerison + ", symptomes=" + symptomes + ", traitement=" + traitement + '}';
    }
    
    
}
