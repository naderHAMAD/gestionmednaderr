
package entities;

class Stock {
    private long idPharmacie;
    private Medicament medicament;
    private int quantite;
    private String statut;

    public long getIdPharmacie() {
        return idPharmacie;
    }

    public void setIdPharmacie(long idPharmacie) {
        this.idPharmacie = idPharmacie;
    }

    public Medicament getMedicament() {
        return medicament;
    }

    public void setMedicament(Medicament medicament) {
        this.medicament = medicament;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    @Override
    public String toString() {
        return "Stock{" + "idPharmacie=" + idPharmacie + ", medicament=" + medicament + ", quantite=" + quantite + ", statut=" + statut + '}';
    }
    
    
}
