package entities;


public class Analyse{
        private float gr;
    private String patientnom;
    private String patientprenom;
    private float gb ;
    private float vgm;
    private float Lymphocyte;
    private float Monocyte;
    private float id;
    private float Reticulocyte;
    private float Hemoglobine;

    public Analyse () {}
    public Analyse(float gr, String patientnom, String patientprenom, float id ,float gb, float vgm , float Lymphocyte , float Monocyte , float Reticulocyte , float Hemoglobine ) {
        this.gr = gr;
        this.patientnom = patientnom;
        this.patientprenom = patientprenom;
    }

    public float getGr() {
        return gr;
    }

    public String getNom() {
        return patientnom;
    }

    public String getPrenom() {
        return patientprenom;
    }
    
     public float getId() {
        return id;
    }
    public float getGb() {
        return gb;
    }
    
    public float getVgm() {
        return vgm;
    }
    
    public float getLymphocyte() {
        return Lymphocyte;
    }
    
    public float getMonocyte() {
        return Monocyte;
    }
    public float getReticulocyte() {
        return Reticulocyte;
    }
    public float getHemoglobine() {
        return Hemoglobine;
    }
    
    public void setGr(float gr) {
        this.gr = gr;
    }

    public void setNom(String patientnom) {
        this.patientnom = patientnom;
    }

    public void setPrenom(String patientprenom) {
        this.patientprenom = patientprenom;
    }
    public void setId(float id) {
        this.id = id;
    }

    public void setGb(float gb) {
        this.gb = gb;
    }
    
    public void setVgm(float vgm) {
        this.vgm = vgm;
    }
    
    public void setLymphocyte(float Lymphocyte) {
        this.Lymphocyte = Lymphocyte;
    }
    
     public void setMonocyte(float Monocyte) {
        this.Monocyte = Monocyte;
    }
    public void setReticulocyte(float Reticulocyte) {
        this.Reticulocyte = Reticulocyte;
    }
    public void setHemoglobine(float Hemoglobine) {
        this.Hemoglobine = Hemoglobine;
    }

    
    @Override
    public String toString() {
        return "Analyse{" + "gr=" + gr + ", patientnom=" + patientnom + "id" + id + " patientprenom=" + patientprenom + "gb=" + gb + " vgm=" + vgm + "Lymphocte" + Lymphocyte + "monocyte" + Monocyte + "Reticulocyte" + Reticulocyte + "Hemoglobine" + Hemoglobine + '}';
    }
  
    
}
