/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author anasb
 */
public class Ordonnance {
    private long ordonnanceId;
    private long idMed;
    private String cinPatient;
    private String medicaments;
    private Date date;

    public Ordonnance(long idMed, String cinPatient, String medicaments, Date date) {
        this.idMed = idMed;
        this.cinPatient = cinPatient;
        this.medicaments = medicaments;
        this.date = date;
    }

    public Ordonnance() {
        
    }

    public long getIdMed() {
        return idMed;
    }

    public void setIdMed(long idMed) {
        this.idMed = idMed;
    }

    public long getOrdonnanceId() {
        return ordonnanceId;
    }

    public void setOrdonnanceId(long ordonnanceId) {
        this.ordonnanceId = ordonnanceId;
    }
    
    public String getCinPatient() {
        return cinPatient;
    }

    public void setCinPatient(String cinPatient) {
        this.cinPatient = cinPatient;
    }

    public String getMedicaments() {
        return medicaments;
    }

    public void setMedicaments(String medicaments) {
        this.medicaments = medicaments;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Ordonnance{" + "idMed=" + idMed + ", cinPatient=" + cinPatient +  ", medicaments=" + medicaments + ", date=" + date + '}';
    }
    
    
}
