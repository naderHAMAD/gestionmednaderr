package entities;

import java.util.Date;


public class Citoyen extends User {
    private String cin;
    private String Nom;
    private String prenom;
    private Date dateNaissance;
    private int age;
    private String adresse;
    private int idProfilSanitaire;
    private String numTel;
    private int idProfilSecSociale;
    private String groupeSanguin;

    public Citoyen() {
        super();
    }

    public Citoyen(String cin, String Nom, String prenom, Date dateNaissance, int age, String adresse, int idProfilSanitaire, String numTel, int idProfilSecSociale, String groupeSanguin) {
        super();
        this.cin = cin;
        this.Nom = Nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.age = age;
        this.adresse = adresse;
        this.idProfilSanitaire = idProfilSanitaire;
        this.numTel = numTel;
        this.idProfilSecSociale = idProfilSecSociale;
        this.groupeSanguin = groupeSanguin;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getIdProfilSanitaire() {
        return idProfilSanitaire;
    }

    public void setIdProfilSanitaire(int idProfilSanitaire) {
        this.idProfilSanitaire = idProfilSanitaire;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public int getIdProfilSecSociale() {
        return idProfilSecSociale;
    }

    public void setIdProfilSecSociale(int idProfilSecSociale) {
        this.idProfilSecSociale = idProfilSecSociale;
    }

    public String getGroupeSanguin() {
        return groupeSanguin;
    }

    public void setGroupeSanguin(String groupeSanguin) {
        this.groupeSanguin = groupeSanguin;
    }

    @Override
    public String toString() {
        return "Citoyen{" + "cin=" + cin + ", Nom=" + Nom + ", prenom=" + prenom + ", dateNaissance=" + dateNaissance + ", age=" + age + ", adresse=" + adresse + ", idProfilSanitaire=" + idProfilSanitaire + ", numTel=" + numTel + ", idProfilSecSociale=" + idProfilSecSociale + ", groupeSanguin=" + groupeSanguin + '}';
    }
    
    
    
}
