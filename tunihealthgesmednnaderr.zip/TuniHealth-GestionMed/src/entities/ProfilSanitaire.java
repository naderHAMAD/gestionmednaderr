
package entities;

import java.io.File;
import java.util.List;


public class ProfilSanitaire {
    private long idCitoyen;
    private List<File> attachements;
    private List<Analyse> analyses;
    private float poids;
    private int tailleCm;
    private List<Maladie> maladies;
    private List<Vaccination> vaccinations;
    private List<InterventionChirurgicale> interventionsChirurgicales;
    private List<Habitude> habitudes;
    private String antecedentsFamiliaux;

    public ProfilSanitaire(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public ProfilSanitaire(long idCitoyen, List<Analyse> analyses, float poids, int tailleCm, List<Maladie> maladies, List<Vaccination> vaccinations, List<InterventionChirurgicale> interventionsChirurgicales, List<Habitude> habitudes, String antecedentsFamiliaux) {
        this.idCitoyen = idCitoyen;
        this.analyses = analyses;
        this.poids = poids;
        this.tailleCm = tailleCm;
        this.maladies = maladies;
        this.vaccinations = vaccinations;
        this.interventionsChirurgicales = interventionsChirurgicales;
        this.habitudes = habitudes;
        this.antecedentsFamiliaux = antecedentsFamiliaux;
    }

    public long getIdCitoyen() {
        return idCitoyen;
    }

    public void setIdCitoyen(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public List<File> getAttachements() {
        return attachements;
    }

    public void setAttachements(List<File> attachements) {
        this.attachements = attachements;
    }

    public List<Analyse> getAnalyses() {
        return analyses;
    }

    public void setAnalyses(List<Analyse> analyses) {
        this.analyses = analyses;
    }

    public float getPoids() {
        return poids;
    }

    public void setPoids(float poids) {
        this.poids = poids;
    }

    public int getTailleCm() {
        return tailleCm;
    }

    public void setTailleCm(int tailleCm) {
        this.tailleCm = tailleCm;
    }

    public List<Maladie> getMaladies() {
        return maladies;
    }

    public void setMaladies(List<Maladie> maladies) {
        this.maladies = maladies;
    }

    public List<Vaccination> getVaccinations() {
        return vaccinations;
    }

    public void setVaccinations(List<Vaccination> vaccinations) {
        this.vaccinations = vaccinations;
    }

    public List<InterventionChirurgicale> getInterventionsChirurgicales() {
        return interventionsChirurgicales;
    }

    public void setInterventionsChirurgicales(List<InterventionChirurgicale> interventionsChirurgicales) {
        this.interventionsChirurgicales = interventionsChirurgicales;
    }

    public List<Habitude> getHabitudes() {
        return habitudes;
    }

    public void setHabitudes(List<Habitude> habitudes) {
        this.habitudes = habitudes;
    }

    public String getAntecedentsFamiliaux() {
        return antecedentsFamiliaux;
    }

    public void setAntecedentsFamiliaux(String antecedentsFamiliaux) {
        this.antecedentsFamiliaux = antecedentsFamiliaux;
    }

    @Override
    public String toString() {
        return "ProfilSanitaire{" + "idCitoyen=" + idCitoyen + ", attachements=" + attachements + ", analyses=" + analyses + ", poids=" + poids + ", tailleCm=" + tailleCm + ", maladies=" + maladies + ", vaccinations=" + vaccinations + ", interventionsChirurgicales=" + interventionsChirurgicales + ", habitudes=" + habitudes + ", antecedentsFamiliaux=" + antecedentsFamiliaux + '}';
    }
    
    
    
    
}
