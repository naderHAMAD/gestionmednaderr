package entities;

import java.util.List;

public class Medecin extends User{
    private long medId;
    private String nom;
    private String prenom;
    private String specialite;
    private String numTelPro;
    private String AdresseCabinet;
    private String region;
    private float rating = 0;
    private int nombreRatings;
    private String horairesDispo;
    private List<Long> consutations;
    private String joursTravail;
    private int prixVisite;
    private boolean hospitalier;
    private boolean conventionne;
    
    public Medecin(){
        
    }

    public Medecin( String nom, String prenom, String specialite, String numTelPro, String AdresseCabinet,String region, String horairesDispo, List<Long> consutations, String joursTravail,int prixVisite, boolean hospitalier, boolean conventionne) {
        
        this.nom = nom;
        this.prenom = prenom;
        this.specialite = specialite;
        this.numTelPro = numTelPro;
        this.AdresseCabinet = AdresseCabinet;
        this.region = region;
        this.horairesDispo = horairesDispo;
        this.consutations = consutations;
        this.joursTravail = joursTravail;
        this.prixVisite = prixVisite;
        this.hospitalier = hospitalier;
        this.conventionne = conventionne;
    }

    public Medecin(int rid, String rnom2, String rprenom2, String rspecialite2, String rcontact2, String rcabinet2, String rhopital2, String rcontact3, String rcabinet4, String rhopital5, boolean hos, boolean conv) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public long getMedId() {
        return medId;
    }

    public int getPrixVisite() {
        return prixVisite;
    }

    public void setPrixVisite(int prixVisite) {
        this.prixVisite = prixVisite;
    }

    public void setMedId(long medId) {
        this.medId = medId;
    }

    public String getHorairesDispo() {
        return horairesDispo;
    }

    public void setHorairesDispo(String horairesDispo) {
        this.horairesDispo = horairesDispo;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
    
    public List<Long> getConsutations() {
        return consutations;
    }

    public void setConsutations(List<Long> consutations) {
        this.consutations = consutations;
    }

    public String getJoursTravail() {
        return joursTravail;
    }

    public void setJoursTravail(String joursTravail) {
        this.joursTravail = joursTravail;
    }

    public boolean isHospitalier() {
        return hospitalier;
    }

    public void setHospitalier(boolean hospitalier) {
        this.hospitalier = hospitalier;
    }

    public boolean isConventionne() {
        return conventionne;
    }

    public void setConventionne(boolean conventionne) {
        this.conventionne = conventionne;
    }
    
    
    

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }
    
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNumTelPro() {
        return numTelPro;
    }

    public void setNumTelPro(String numTelPro) {
        this.numTelPro = numTelPro;
    }

    public String getAdresseCabinet() {
        return AdresseCabinet;
    }

    public void setAdresseCabinet(String adresseCabinet) {
        AdresseCabinet = adresseCabinet;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getNombreRatings() {
        return nombreRatings;
    }

    public void setNombreRatings(int nombreRatings) {
        this.nombreRatings = nombreRatings;
    }

    @Override
    public String toString() {
        return "Medecin{" + "nom=" + nom + ", prenom=" + prenom + ", specialite=" + specialite + ", numTelPro=" + numTelPro + ", AdresseCabinet=" + AdresseCabinet + ", rating=" + rating + ", horairesDispo=" + horairesDispo + ", consutations=" + consutations + ", joursTravail=" + joursTravail + ", hospitalier=" + hospitalier + ", conventionne=" + conventionne + '}';
    }

    
}
