
package entities;


public class ProfilSecSociale {
    private long idCitoyen;
    private String type;
    private String modePaiement;

    public ProfilSecSociale(long idCitoyen, String type, String modePaiement) {
        this.idCitoyen = idCitoyen;
        this.type = type;
        this.modePaiement = modePaiement;
    }

    public long getIdCitoyen() {
        return idCitoyen;
    }

    public void setIdCitoyen(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getModePaiement() {
        return modePaiement;
    }

    public void setModePaiement(String modePaiement) {
        this.modePaiement = modePaiement;
    }
    
    
}
