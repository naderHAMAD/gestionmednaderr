
package entities;

import java.util.List;

public class Habitude {
    private long idCitoyen;
    private String activitePhysique;
    private int niveauStress;
    private int qualiteSommeil;
    private List<String> mauvaisesHabitudes;

    public Habitude(String activitePhysique, int niveauStress, int qualiteSommeil, List<String> mauvaisesHabitudes) {
        this.activitePhysique = activitePhysique;
        this.niveauStress = niveauStress;
        this.qualiteSommeil = qualiteSommeil;
        this.mauvaisesHabitudes = mauvaisesHabitudes;
    }

    public Habitude() {
    }

    public long getIdCitoyen() {
        return idCitoyen;
    }

    public void setIdCitoyen(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public String getActivitePhysique() {
        return activitePhysique;
    }

    public void setActivitePhysique(String activitePhysique) {
        this.activitePhysique = activitePhysique;
    }

    public int getNiveauStress() {
        return niveauStress;
    }

    public void setNiveauStress(int niveauStress) {
        this.niveauStress = niveauStress;
    }

    public int getQualiteSommeil() {
        return qualiteSommeil;
    }

    public void setQualiteSommeil(int qualiteSommeil) {
        this.qualiteSommeil = qualiteSommeil;
    }

    public List<String> getMauvaisesHabitudes() {
        return mauvaisesHabitudes;
    }

    public void setMauvaisesHabitudes(List<String> mauvaisesHabitudes) {
        this.mauvaisesHabitudes = mauvaisesHabitudes;
    }

    @Override
    public String toString() {
        return "Habitude{" + "idCitoyen=" + idCitoyen + ", activitePhysique=" + activitePhysique + ", niveauStress=" + niveauStress + ", qualiteSommeil=" + qualiteSommeil + ", mauvaisesHabitudes=" + mauvaisesHabitudes + '}';
    }
    
    
}
