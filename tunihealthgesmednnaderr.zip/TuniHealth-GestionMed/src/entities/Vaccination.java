
package entities;

import java.util.Date;

/**
 *
 * @author anasb
 */
public class Vaccination {
    private long idCitoyen;
    private String nomVaccin;
    private String categorie;
    private Date dateVaccination;
    private Date dureeValidite;

    public Vaccination(long idCitoyen, String nomVaccin, String categorie, Date dateVaccination, Date dureeValidite) {
        this.idCitoyen = idCitoyen;
        this.nomVaccin = nomVaccin;
        this.categorie = categorie;
        this.dateVaccination = dateVaccination;
        this.dureeValidite = dureeValidite;
    }

    public long getIdCitoyen() {
        return idCitoyen;
    }

    public void setIdCitoyen(long idCitoyen) {
        this.idCitoyen = idCitoyen;
    }

    public String getNomVaccin() {
        return nomVaccin;
    }

    public void setNomVaccin(String nomVaccin) {
        this.nomVaccin = nomVaccin;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public Date getDateVaccination() {
        return dateVaccination;
    }

    public void setDateVaccination(Date dateVaccination) {
        this.dateVaccination = dateVaccination;
    }

    public Date getDureeValidite() {
        return dureeValidite;
    }

    public void setDureeValidite(Date dureeValidite) {
        this.dureeValidite = dureeValidite;
    }

    @Override
    public String toString() {
        return "Vaccination{" + "idCitoyen=" + idCitoyen + ", nomVaccin=" + nomVaccin + ", categorie=" + categorie + ", dateVaccination=" + dateVaccination + ", dureeValidite=" + dureeValidite + '}';
    }
    
    
}
